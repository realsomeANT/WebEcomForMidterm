using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Yot_Login2.Models;

namespace Yot_Login2.Controllers
{
    public class AboutController : Controller
    {
        private readonly ILogger<AboutController> _logger;

        public AboutController(ILogger<AboutController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}
