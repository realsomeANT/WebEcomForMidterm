﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Yot_Login2.Models;

namespace Yot_Login2.ViewModels
{
	public class EditUser_Name
	{
		[Required(ErrorMessage = "Enter your new name")]
		public string? UserFirstName { get; set; }
	}
}
