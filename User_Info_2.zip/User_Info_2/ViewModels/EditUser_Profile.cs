﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Yot_Login2.Models;

namespace Yot_Login2.ViewModels
{
    public class EditUser_Profile
    {
        public byte[]? UserProfile { get; set; }
        [NotMapped]
        public IFormFile? UserProfile_IFormFile { get; set; }
    }
}
