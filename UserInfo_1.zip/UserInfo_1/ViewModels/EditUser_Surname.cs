﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Yot_Login2.Models;

namespace Yot_Login2.ViewModels
{
	public class EditUser_Surname
	{
		[Required(ErrorMessage = "Enter your new surname")]
		public string? UserSurname { get; set; }
	}
}
