﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Yot_Login2.Models;

namespace Yot_Login2.ViewModels
{
	public class EditUser_Address
	{
		[Required(ErrorMessage = "Enter your new address")]
		public string? UserAddress { get; set; }
	}
}
