﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Yot_Login2.Models;

namespace Yot_Login2.ViewModels
{
	public class EditUser_PhoneNumber
	{
		[Required(ErrorMessage = "Enter your new phone number")]
		public int UserPhoneNumber { get; set; }
	}
}
