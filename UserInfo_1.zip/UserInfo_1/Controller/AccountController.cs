﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yot_Login2.Data;
using Yot_Login2.Models;
using Yot_Login2.ViewModels;

namespace Yot_Login2.Controllers
{
    public class AccountController : Controller
    {
        private readonly SignInManager<Users> signInManager;
        private readonly UserManager<Users> userManager;
        // private readonly YourDbContext _context;
        private readonly _IdentityDbContext _context;

        public AccountController(SignInManager<Users> signInManager, UserManager<Users> userManager, _IdentityDbContext context)
        {
            this.signInManager = signInManager;
            this.userManager = userManager;
            _context = context;
        }

        public IActionResult Login()
        {
            return View();
        }

        public async Task<Users> GetUserByEmailAsync(string email)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var result = await signInManager.PasswordSignInAsync(model.UserEmail, model.UserPassword, model.RememberMe, false);

                if (result.Succeeded)
                {
                    var user = await GetUserByEmailAsync(model.UserEmail);

                    if (user != null)
                    {
                        // Check the UserCategory
                        if (user.UserCategory == "User")
                        {
                            // Redirect to the home page for "User" category
                            return RedirectToAction("Index", "Home");
                        }
                        else
                        {
                            // Handle other categories or redirect to a specific page
                            // For example, redirect to an admin dashboard:
                            return RedirectToAction("Privacy", "Home");
                        }
                    }
                    else
                    {
                        // Handle the case where the user is not found
                        ModelState.AddModelError("", "User not found.");
                        return View(model);
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Email or password is incorrect.");
                    return View(model);
                }
            }
            return View(model);
        }

        public IActionResult Register()
        {
            return View();
        }
        
        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                Users user = new Users()
                {
                    UserName = model.UserEmail,
                    UserFirstName = model.UserFirstName,
                    UserSurname = model.UserSurname,
                    Email = model.UserEmail,
                    UserPassword = model.UserPassword,
                    UserConfirmPassword = model.UserConfirmPassword,
                    UserAddress = model.UserAddress,
                    UserPhoneNumber = model.UserPhoneNumber,
                    UserCategory = "User",
                };

                var result = await userManager.CreateAsync(user, model.UserPassword);

                if (result.Succeeded)
                {
                    return RedirectToAction("Login", "Account");
                }
                else
                {
                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }

                    return View(model);
                }
            }
            return View(model);
        }
        public async Task<IActionResult> Logout()
        {
            await signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }

		public async Task<IActionResult> EditUser()
        {
            var user = await userManager.GetUserAsync(User);
            ViewBag.UserFirstName = user.UserFirstName;
            ViewBag.UserSurname = user.UserSurname;
            ViewBag.Email = user.Email;
            ViewBag.UserPhoneNumber = user.UserPhoneNumber;
            ViewBag.UserAddress = user.UserAddress;
            return View();
		}
		public IActionResult EditUser_Name()
		{
			return View();
		}

        [HttpPost]
        public async Task<IActionResult> EditUser_Name(EditUser_Name model)
        {
            if (ModelState.IsValid)
            {
                var user = await userManager.GetUserAsync(User);

                if (user != null)
                {
                    user.UserFirstName = model.UserFirstName; // Update the property

                    var result = await userManager.UpdateAsync(user);

                    if (result.Succeeded)
                    {
                        // Update successful, handle success
                        return RedirectToAction("EditUser", "Account");
                    }
                    else
                    {
                        // Handle update errors
                        foreach (var error in result.Errors)
                        {
                            ModelState.AddModelError(string.Empty, error.Description);
                        }
                    }
                }
                else
                {
                    // Handle the case where the user is not found
                    ModelState.AddModelError(string.Empty, "User not found.");
                }
            }
            return View(model);
        }

        public IActionResult EditUser_Surname()
		{
			return View();
		}

        [HttpPost]
        public async Task<IActionResult> EditUser_Surname(EditUser_Surname model)
        {
            if (ModelState.IsValid)
            {
                var user = await userManager.GetUserAsync(User);

                if (user != null)
                {
                    user.UserSurname = model.UserSurname; // Update the property

                    var result = await userManager.UpdateAsync(user);

                    if (result.Succeeded)
                    {
                        // Update successful, handle success
                        return RedirectToAction("EditUser", "Account");
                    }
                    else
                    {
                        // Handle update errors
                        foreach (var error in result.Errors)
                        {
                            ModelState.AddModelError(string.Empty, error.Description);
                        }
                    }
                }
                else
                {
                    // Handle the case where the user is not found
                    ModelState.AddModelError(string.Empty, "User not found.");
                }
            }
            return View(model);
        }

        public IActionResult EditUser_Email()
		{
			return View();
		}

        [HttpPost]
        public async Task<IActionResult> EditUser_Email(EditUser_Email model)
        {
            if (ModelState.IsValid)
            {
                var user = await userManager.GetUserAsync(User);

                if (user != null)
                {
                    user.Email = model.Email; // Update the property
                    user.UserName = model.Email; // Bug fix

                    var result = await userManager.UpdateAsync(user);

                    if (result.Succeeded)
                    {
                        // Update successful, handle success
                        return RedirectToAction("EditUser", "Account");
                    }
                    else
                    {
                        // Handle update errors
                        foreach (var error in result.Errors)
                        {
                            ModelState.AddModelError(string.Empty, error.Description);
                        }
                    }
                }
                else
                {
                    // Handle the case where the user is not found
                    ModelState.AddModelError(string.Empty, "User not found.");
                }
            }
            return View(model);
        }
        public IActionResult EditUser_PhoneNumber()
		{
			return View();
		}

        [HttpPost]
        public async Task<IActionResult> EditUser_PhoneNumber(EditUser_PhoneNumber model)
        {
            if (ModelState.IsValid)
            {
                var user = await userManager.GetUserAsync(User);

                if (user != null)
                {
                    user.UserPhoneNumber = model.UserPhoneNumber; // Update the property

                    var result = await userManager.UpdateAsync(user);

                    if (result.Succeeded)
                    {
                        // Update successful, handle success
                        return RedirectToAction("EditUser", "Account");
                    }
                    else
                    {
                        // Handle update errors
                        foreach (var error in result.Errors)
                        {
                            ModelState.AddModelError(string.Empty, error.Description);
                        }
                    }
                }
                else
                {
                    // Handle the case where the user is not found
                    ModelState.AddModelError(string.Empty, "User not found.");
                }
            }
            return View(model);
        }

        public IActionResult EditUser_Address()
		{
			return View();
		}

        [HttpPost]
        public async Task<IActionResult> EditUser_Address(EditUser_Address model)
        {
            if (ModelState.IsValid)
            {
                var user = await userManager.GetUserAsync(User);

                if (user != null)
                {
                    user.UserAddress = model.UserAddress; // Update the property

                    var result = await userManager.UpdateAsync(user);

                    if (result.Succeeded)
                    {
                        // Update successful, handle success
                        return RedirectToAction("EditUser", "Account");
                    }
                    else
                    {
                        // Handle update errors
                        foreach (var error in result.Errors)
                        {
                            ModelState.AddModelError(string.Empty, error.Description);
                        }
                    }
                }
                else
                {
                    // Handle the case where the user is not found
                    ModelState.AddModelError(string.Empty, "User not found.");
                }
            }
            return View(model);
        }

    }
}

